DG FAMILY WELLNESS — VERSION 1 STARTER

What this is:
- A mobile-first Progressive Web App starter.
- Home, Learn, My Plans, Profile.
- Four content areas: Doctor Diaries, Parent Fitness, Parent Nutrition, Kids' Nutrition.
- Search, category filters, resource details, save-to-plans on this device, share resource, PWA manifest and offline caching.
- Uses sample educational content only. Review all clinical content before public launch.

Files:
- index.html: app and sample content
- manifest.json: install metadata
- sw.js: basic offline caching
- icon.svg: app icon

Important:
- This is a starter prototype, not a medical device and not a clinical service.
- Saved resources use local browser storage and do not sync.
- No user accounts, server database, payments, push notifications or admin dashboard yet.
- To test as an installable PWA, host it on HTTPS. Opening index.html directly from the Files app will not enable installation/offline features.
- Never add identifiable patient information or private health records to this prototype.

Phone-friendly next step:
1. Download and extract the ZIP using the Files app.
2. Create a private or public repository on GitHub in Safari and upload the four files (index.html, manifest.json, sw.js, icon.svg) to the repository root.
3. In GitHub repository Settings → Pages, choose Deploy from a branch, select the main branch and /(root), then Save.
4. Wait for the Pages URL. Open it in Safari on iPhone → Share → Add to Home Screen. On Android, open the URL in Chrome → menu → Install app / Add to Home screen.
5. Test each tab and save a resource. Do not share it publicly until the clinical content and privacy notice have been reviewed.

If the GitHub mobile interface is difficult, use a trusted helper with a laptop for the one-time upload; no coding is required to edit the sample text later, but updating content inside index.html will involve editing a file.
